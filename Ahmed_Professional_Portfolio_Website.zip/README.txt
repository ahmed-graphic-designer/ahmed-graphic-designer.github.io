# Ahmed — Graphic Design Portfolio

## Included
- `index.html` — complete portfolio website
- `style.css` — responsive modern styling

## Your details
Name: Ahmed
Address: Wadala Sandhwan, Tehsil Daska, District Sialkot
Phone: +92 339 6192241
Email: ahmadamanullah18@gmail.com

## How to publish
Upload `index.html` and `style.css` to any static hosting service such as Netlify, GitHub Pages, or Cloudflare Pages.
